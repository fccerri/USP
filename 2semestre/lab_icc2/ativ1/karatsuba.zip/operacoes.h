#ifndef OPERACOES_H
#define OPERACOES_H

char* multiply(char* str1, char* str2);
//char* multiplicacao(const char* str1, const char* str2);
char* add(char* str1, char* str2);
char* sub(char* str1, char* str2);
char* potencia_de_10(const char* str, int potencia);
char* karatsuba(char* str1, char* str2);
char * multiplicacao(char *str1, char *str2);
#endif
