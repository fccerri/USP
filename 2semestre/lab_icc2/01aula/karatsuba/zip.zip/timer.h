#ifndef TIMER_H
    #define TIMER_H
    
    typedef struct timer_ TIMER;
    void start_timer(TIMER *timer);
    double stop_timer(TIMER *timer);

#endif
