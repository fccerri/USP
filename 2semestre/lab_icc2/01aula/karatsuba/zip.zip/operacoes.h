#ifndef OPERACOES_H
#define OPERACOES_H

char* multiplicacao(const char* str1, const char* str2);
char* add(char* str1, char* str2);
char* sub(char* str1, char* str2);
char* potencia_de_10(const char* str, int potencia);

#endif
